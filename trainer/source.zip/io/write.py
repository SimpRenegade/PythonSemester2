# file write.py

fobj = open('data_out.txt', 'w')
fobj.write('first line\n')
fobj.write('second line\nthird line\n')
fobj.close()