while True:
    eingabe = input('Bitte geben Sie eine Zahl ein: ')
    if eingabe == 'q':
        break
    print('Ihre Eingabe war:', eingabe)
