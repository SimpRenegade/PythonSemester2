eingabe = input('Bitte geben Sie eine Zahl ein: ')
print('Ihre Eingabe war:', eingabe)
