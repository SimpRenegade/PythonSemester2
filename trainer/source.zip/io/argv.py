# datei argv.py

import sys

print('Kommandozeilenargumente:')
for arg in sys.argv:
    print(arg)